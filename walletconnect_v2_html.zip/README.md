WalletConnect v2 — Full HTML Demo (Modern)
=========================================

What this ZIP contains
- index.html : a standalone single-file demo using WalletConnect v2 (SignClient) + Web3Modal (standalone) + ethers (CDN imports).
- README.md  : this file

How to run
1. Extract the ZIP to a folder.
2. Serve it via a local server (do NOT open with file:// )
   - Python (fastest): `python -m http.server 8000`
   - Node: `npx http-server .` or `http-server`
3. Open in your browser: http://localhost:8000
4. Click 'Connect Wallet' → scan QR with a mobile wallet that supports WalletConnect v2 (e.g., MetaMask Mobile, Rainbow, Trust Wallet, etc.).
5. After approve, the demo will show the connected address and ETH balance (read via public RPC).

Notes
- The Project ID is already set to: a9ca60975a434a874c01a34c5f7ff722
- The demo queries the ETH balance from Cloudflare public RPC (https://cloudflare-eth.com) for read-only requests.
- This solution is intended to work in a regular browser (desktop/mobile) and does not require MetaMask extension.
- If there are issues loading modules from CDN (esm.sh), try a network that allows CDN access or run a simple bundler environment. Some browsers may block module imports from some CDNs in strict privacy settings.

Troubleshooting
- 'Blank' page: make sure you run a local server and open http://localhost:8000
- 'localStorage' errors: indicates you opened using file:// or inside a sandboxed iframe — use a local server.
- If Web3Modal fails to open, check console for CORS or network errors.

If you want, I can also provide a ZIP variant that bundles necessary dependencies so it works fully offline — tell me if you want an offline/bundled build.
